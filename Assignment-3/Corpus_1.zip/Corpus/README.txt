
CONLLU File Format:

Refer to the link https://universaldependencies.org/format.html to get an intuition of the CONLLU format.

Files in the Corpus:

1. eng.train.conllu : Training corpus of English language.
2. eng.test.conllu : Training corpus of English language.
1. spanish.train.conllu : Training corpus of Spanish language.
2. spanish.test.conllu : Training corpus of Spanish language.